package ua.itaysonlab.hfsdk.content

import android.os.Parcelable

abstract class BaseContent: Parcelable